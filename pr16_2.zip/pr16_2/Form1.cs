﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection.Emit;

namespace pr16_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] m = textBox1.Text.Split(' ');
            bool sl = m.Any(s => s.Contains("/"));
            if (sl == true)
            {
                var k = m.SelectMany(s => s).Count(char.IsDigit);
                textBox2.Text = k.ToString();

                if (File.Exists("file1.txt"))
                {
                    using (StreamWriter write = new StreamWriter("file1.txt"))
                    {
                        var before = m.TakeWhile(s => s != "/").ToList();
                        foreach (var b in before)
                        {
                            textBox3.Text = b;
                            write.Write(b);
                        }
                        var sl2 = m.SkipWhile(s => s != "/").Select(s => string.Concat(s.Select(a => char.IsUpper(a) ? char.ToLower(a) : char.ToUpper(a)))).ToArray();

                        foreach (var s in sl2)
                        {
                            textBox4.Text += s;
                            write.Write(s);
                        }

                    }
                }
                else MessageBox.Show("Файл не найден");
            }
            else MessageBox.Show("В строке нет '/'");
        }
          
       }
   }

        
    

