﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите название файла");
            string name = Console.ReadLine();
            if (File.Exists(name))
            {
                string[] text = File.ReadAllLines("file.txt");
                Console.WriteLine("Ваш текст:");
                  foreach(var s in text)
                {
                    Console.WriteLine(s);
                }
                string find = "";
                bool temp = false;
                do
                {
                    Console.WriteLine("Введите слово");
                    find = Console.ReadLine();
                    temp = find.All(char.IsLetter);
                }
                while (temp == false);

                if (temp == true)
                {
                    int k = text.SelectMany(tex => tex.Split(new char[] { ' ', '.', '!', '?', ',', ';', ':' }, StringSplitOptions.RemoveEmptyEntries)).Where(word => word.ToLower() == find.ToLower()).Count();
                    Console.WriteLine($"Слово '{find}' встречается в тексте {k} раз ");

                }
                else
                {
                    Console.WriteLine("Вы ввели неправильно слово");
                }
            }
            else
            {
                Console.WriteLine("Файл не найден");
            }
            Console.ReadLine();
        }
    }
}
